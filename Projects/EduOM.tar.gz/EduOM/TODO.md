### TODO List
API Functions
- [x] EduOM_CreateObject()
- [ ] EduOM_DestoryObject()
- [x] EduOM_CompactPage()
- [x] EduOM_ReadObject()
- [x] EduOM_NextObject()
- [ ] EduOM_PrevObject()

Internal Functions
- [ ] eduom_CreateObject()